<?php
include "../../dbconn.php";

$getdatas = "SELECT nc.clientcompany, ncs.countryName FROM clientcompanydata nc LEFT JOIN nus_countries ncs ON ncs.countryId=nc.country WHERE nc.id=".$_POST['clientId']."";
$result = $conn->query($getdatas);
$clientname = '';
$clientCountry = '';
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
	    $clientname = $row['clientcompany'];
	    $clientCountry = $row['countryName'];
	}
}
$alldetails = array("clientname"=> $clientname, "clientcountry"=>$clientCountry);
echo json_encode($alldetails);
?>