<?php
    include('security.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS Consulting Group | Parent Company List</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <link
      rel="stylesheet"
      href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css"
    />
    <link rel="stylesheet" type="text/css" href="css/style.css" />

    <style>

        #DataTables_Table_0_wrapper {
            position: absolute;
            width: 87%;
            margin: 80px 0 0 360px;
        }

       #myTable_wrapper {
            position: absolute;
            width: 76%;
            margin: 0px 0 0 300px;
        }

      
        table {
            border: 2px solid #D2DDEC;
            border-radius: 6px;
            width: 76%;
            margin: 10px 300px;
            /* height: 70vh; */
        }
        /* table.dataTable thead > tr > th.sorting_asc::before {
            opacity: 1;
            position: absolute;
            left: 13%;
            color: black;
        }
        table.dataTable thead > tr > th.sorting::after {
            opacity: 1;
            position: absolute;
            left: 13%;
            color: black;
        } */
        table th {
            color: #343a40;
            background: #F9FBFD;
        }
        table.myTable thead th {
            border-bottom: 1px solid #CED4DA !important;
        }
        table td {
            color: #12263F;
            font-size: 13px;
            border-bottom: 1px solid #CED4DA;
        }
        table.dataTable.no-footer {
            /* border-bottom: 2px solid #D2DDEC !important; */
            border-bottom: none !important;
        }

        table tbody td {
            color: #345DA6;
        }

        .parentdatas{
            text-decoration: none;
        }
        .parent {
            text-align:left;
        }
        .clientfrs {
            margin: 40px 0 0 300px;
            position: relative;
            top: 8%;
            font-weight: 600;
            font-size: 20px;
        }
    </style>
</head>
<body>
<div class="main">
        <div class="menu">

            <?php
                include('sidebar.php');
            ?>
        </div>
    <div>
    <pre><p><a href="addhome.php" class="clientfrs" >List of supply contracts </a></p></pre>
<div class="padmd0">
        <table class="myTable" id="myTable">
        <thead class="">
            <!-- <tr> -->
            <th class="">contract name</th>
            <th class="">Client</th>
            <th class="">Country</th>
            <th class="">Contract Start</th>
            <th class="">Contract End</th>
            <th class="">Status</th>
            <th class="">Commodity</th>
            <th class="">Contract Type</th>
            <!-- </tr> -->
        </thead>
        <tbody>
        <?php
                include('dbconn.php');

    include 'includes/functions.php';
    $functions = new libFunc();
      
                $user = $_GET['id'];
                $sql = "SELECT * FROM nus_supply_contract WHERE clientId='$user' ORDER BY supplierId DESC";
                $result = mysqli_query($conn,$sql);

                while($row = mysqli_fetch_assoc($result)) {
        ?>
            
                <tr>       
                    <!-- <td><a href=""><a></td> -->
                    <td><?= $row['contract_id']; ?></td>
                    <td><?=$functions->getclientname($row['clientId'])?></td>
                    <td><?= $row['countryName']; ?></td>
                    <td><?= date('d-F-Y',strtotime($row['contractTermfromDate'])); ?></td>
                    <td><?= date('d-F-Y',strtotime($row['contractTermtoDate'])) ?></td>
                    <td><?php 
                    if($row['contractstatus'] == 'A'){
                        echo 'Live';
                    }
                    ?></td>
                    <td><?= $row['commodityName']; ?></td>
                    <td><?= $row['contractType']; ?></td>
                </tr>
            <?php }?>
           
        </tbody>
    </table>

</div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js">
    </script>
    <script>
        $(document).ready( function () {
         $('#myTable').DataTable();
        } );
    </script>
    </body>
</html>
