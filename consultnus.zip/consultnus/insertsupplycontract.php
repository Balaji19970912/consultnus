<?php
include "dbconn.php";
if($_GET['type'] == 'adding'){
    if($_POST['contType'] == 'fixed'){

        $commodityName = '';
        $unit = '';
        foreach($_POST['commodity'] as $value){
             $commodityName =$value;
             if($commodityName == 'natural gas'){
                foreach($_POST['units'] as $values){
                    $unit = $values;
                }
             }
        }
        $contracttype = '';
        $contrindex ='';
        foreach($_POST['contacttype'] as $value){
            $contracttype =$value;
            if($contracttype == 'indexed'){
                $contrindex = $_POST['indexed'];
            }
        }
        $indexstru = '';
        foreach($_POST['indexstr'] as $value){
            $indexstru =$value;
        }
        $startDate = date('Y-m-d',strtotime($_POST['startDate1']));
        $endDate = date('Y-m-d',strtotime($_POST['endDate1']));
        $sql = "INSERT INTO nus_supply_contract (clientId, commodityName, countryName, commodityUnits, supplyName, contractType, contractIndexId, contractTermfromDate, contractTermtoDate, commodityPrice, totalAnualConsumption, indexStructureType, clickTrancheminsize, consumMinsize, openPrizemechanism) VALUES ('".$_POST['client']."', '".$commodityName."','".$_POST['country']."' ,'".$unit."','".$_POST['supplr']."' ,'".$contracttype."', '".$contrindex ."', '".$startDate."', '".$endDate."', '".$_POST['commodityprice']."', '".$_POST['totalanualconsumption']."', '".$indexstru."', '".$_POST['minsizevalue']."', '".$_POST['minsize']."', '".$_POST['openmech']."')";
        $conn->query($sql);
        $last_id = $conn->insert_id;
        $autcm = ($commodityName=='natural gas')?'gas':'elec';
        $getclientname = explode(' ', $_POST['clientname']);
     
        $autoId = $getclientname[0].'-'.$autcm.'-'.$last_id;
        $sqls = "UPDATE nus_supply_contract SET contract_id='".$autoId."' WHERE supplierId =".$last_id."";
        $conn->query($sqls);

    }else{
        $commodityName = '';
        $unit = '';
        foreach($_POST['commodity'] as $value){
             $commodityName =$value;
             if($commodityName == 'natural gas'){
             	foreach($_POST['units'] as $values){
             		$unit = $values;
             	}
             }
        }
        $contracttype = '';
        $contrindex ='';
        foreach($_POST['contacttype'] as $value){
            $contracttype =$value;
            if($contracttype == 'indexed'){
            	$contrindex = $_POST['indexed'];
            }
        }
        $indexstru = '';
        foreach($_POST['indexstr'] as $value){
            $indexstru =$value;
        }
        $startDate = date('Y-m-d',strtotime($_POST['startDate1']));
        $endDate = date('Y-m-d',strtotime($_POST['endDate1']));
        $sql = "INSERT INTO nus_supply_contract (clientId, commodityName, countryName, commodityUnits, supplyName, contractType, contractIndexId, contractTermfromDate, contractTermtoDate, commodityPrice, totalAnualConsumption, indexStructureType, clickTrancheminsize, consumMinsize, openPrizemechanism) VALUES ('".$_POST['client']."', '".$commodityName."','".$_POST['country']."' ,'".$unit."','".$_POST['supplr']."' ,'".$contracttype."', '".$contrindex ."', '".$startDate."', '".$endDate."', '".$_POST['commodityprice']."', '".$_POST['totalanualconsumption']."', '".$indexstru."', '".$_POST['minsizevalue']."', '".$_POST['minsize']."', '".$_POST['openmech']."')";
        $conn->query($sql);
        $last_id = $conn->insert_id;
        $autcm = ($commodityName=='natural gas')?'gas':'elec';
        $getclientname = explode(' ', $_POST['clientname']);
        
        $autoId = $getclientname[0].'-'.$autcm.'-'.$last_id;
        $sqls = "UPDATE nus_supply_contract SET contract_id='".$autoId."' WHERE supplierId =".$last_id."";
        $conn->query($sqls);

        for ($i=0; $i < $_POST['rowcount'] ; $i++) { 
        	if(isset($_POST['tradsel'.$i]) && $_POST['tradsel'.$i] != '' ){
        		$sql = "INSERT INTO nus_tradeperiods (supplierId, periodsId, clicktracnches) VALUES ('".$last_id."', '".$_POST['tradsel'.$i]."', '".$_POST['tranche'.$i]."')";
        		$conn->query($sql);
        	}
        }
    }
}else{
    $commodityName = '';
    $unit = '';
    foreach($_POST['commodity'] as $value){
         $commodityName =$value;
         if($commodityName == 'natural gas'){
            foreach($_POST['units'] as $values){
                $unit = $values;
            }
         }
    }
    $contracttype = '';
    $contrindex ='';
    foreach($_POST['contacttype'] as $value){
        $contracttype =$value;
        if($contracttype == 'indexed'){
            $contrindex = $_POST['indexed'];
        }
    }
    $indexstru = '';
    foreach($_POST['indexstr'] as $value){
        $indexstru =$value;
    }
    $startDate = date('Y-m-d',strtotime($_POST['startDate1']));
    $endDate = date('Y-m-d',strtotime($_POST['endDate1']));
    $sql = "UPDATE nus_supply_contract SET clientId='".$_POST['client']."', commodityName='".$commodityName."', countryName='".$_POST['country']."', commodityUnits='".$unit."', supplyName='".$_POST['supplr']."', contractType='".$contracttype."', contractIndexId='".$contrindex ."', contractTermfromDate='".$startDate."', contractTermtoDate='".$endDate."', commodityPrice='".$_POST['commodityprice']."', totalAnualConsumption='".$_POST['totalanualconsumption']."', indexStructureType='".$indexstru."', clickTrancheminsize='".$_POST['minsizevalue']."', consumMinsize='".$_POST['minsize']."', openPrizemechanism='".$_POST['openmech']."' WHERE supplierId = ".$_GET['sid']."";
    $conn->query($sql);

    $delsql = "DELETE FROM nus_tradeperiods WHERE supplierId=".$_GET['sid']."";
    $conn->query($delsql);

    for ($i=0; $i < $_POST['rowcount'] ; $i++) { 
        if(isset($_POST['tradsel'.$i]) && $_POST['tradsel'.$i] != '' ){
            $insertsql = "INSERT INTO nus_tradeperiods (supplierId, periodsId, clicktracnches) VALUES ('".$_GET['sid']."', '".$_POST['tradsel'.$i]."', '".$_POST['tranche'.$i]."')";
            $insertsql->query($sql);
        }
    }

}
$supplyId = 
header("location:addsupplycontract.php");