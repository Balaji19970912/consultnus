<?php 
require_once('./dbconn.php');
class libFunc
{	

	public static function getclientname($clintId){
		global $conn;
		$countryName ='';
		$getUserRole = "SELECT clientcompany FROM clientcompanydata WHERE id=".$clintId."";
        $result = $conn->query($getUserRole);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
               $countryName = $row['clientcompany'];
            }
        }
		return $countryName;
	}
	
	
}


?>

